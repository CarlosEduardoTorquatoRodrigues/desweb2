# desweb2
crtl l - limpa terminal
mkdir criar pastra
touch - criar um arquivo 
 $ mvn archetype:generate -DgroupId=com.example -DartifactId=simples-sqlite -DarchetypeArtifactId=maven-archetype-quickstart -DinteractiveMode=false

$ mvn compile exec:java -Dexec.mainClass="com.example.Main"
